package helpers;

public class Config {
    static String dbHost = "localhost";
    static String dbPort = "3306";
    static String dbUser = "root";
    static String dbPass = "";
    static String dbName = "cms";
}
